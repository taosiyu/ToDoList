//
//  DataManager.swift
//  ToDos
//
//  Created by 陶思雨 on 2021/7/6.
//

import Foundation

func saveList(list : [ToDoModel]) {
    let array = list.map{ $0.propertyListRepresentation }
    UserDefaults.standard.set(array, forKey: "SavedArray")
    UserDefaults.standard.synchronize()
    
}

func loadList() -> [ToDoModel] {
    if let array = UserDefaults.standard.array(forKey: "SavedArray") as? [[String:Any]] {
        let myarray = array.compactMap{ ToDoModel(dictionary: $0) }
        return myarray
    }
    return [];
}


public extension JSONDecoder {

    func decode<T: Decodable>(from data: Data?) -> T? {
        guard let data = data else {
            return nil
        }
        return try? self.decode(T.self, from: data)
    }

    func decodeInBackground<T: Decodable>(from data: Data?, onDecode: @escaping (T?) -> Void) {
        DispatchQueue.global().async {
            let decoded: T? = self.decode(from: data)

            DispatchQueue.main.async {
                onDecode(decoded)
            }
        }
    }
}

// MARK: - JSONEncoder extensions
public extension JSONEncoder {

    func encode<T: Encodable>(from value: T?) -> Data? {
        guard let value = value else {
            return nil
        }
        return try? self.encode(value)
    }

    func encodeInBackground<T: Encodable>(from encodableObject: T?, onEncode: @escaping (Data?) -> Void) {
        DispatchQueue.global().async {
            let encode = self.encode(from: encodableObject)
            DispatchQueue.main.async {
                onEncode(encode)
            }
        }
    }
}

// MARK: - NSUserDefaults extensions

public extension UserDefaults {

    func set<T: Encodable>(object type: T, for key: String, onEncode: @escaping (Bool) -> Void) throws {

        JSONEncoder().encodeInBackground(from: type) { [weak self] (data) in
            guard let data = data, let `self` = self else {
                onEncode(false)
                return
            }
            self.set(data, forKey: key)
            onEncode(true)
        }
    }

    /// Get Decodable object in UserDefaults
    ///
    /// - Parameters:
    ///   - objectType: Decodable object type
    ///   - forKey: UserDefaults key
    ///   - onDecode: Codable object
    func get<T: Decodable>(object type: T.Type, for key: String, onDecode: @escaping (T?) -> Void) {
        let data = value(forKey: key) as? Data
        JSONDecoder().decodeInBackground(from: data, onDecode: onDecode)
    }
}
