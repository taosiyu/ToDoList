//
//  ImageButton.swift
//  ToDos
//
//  Created by 陶思雨 on 2021/7/5.
//

import UIKit
import SnapKit

class ImageButton: UIImageView {
    
    typealias DoneButtonAction = (Bool) -> Void
    
    var doneButtonAction: DoneButtonAction?
    
    var isAlert: Bool = false
    
    private var button:UIButton = {
        let btn = UIButton.init()
        return btn
    }()
    
    init() {
        super.init(frame: CGRect.init())
        self.addSubview(self.button)
        let conv = self;
        self.button.snp.makeConstraints { make in
            make.top.equalTo(conv.snp.top)
            make.left.equalTo(conv.snp.left)
            make.right.equalTo(conv.snp.right)
            make.bottom.equalTo(conv.snp.bottom)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func activeButton(){
        self.isUserInteractionEnabled = true
        self.button.addTarget(self, action: #selector(doneButtonTriggered), for: UIControl.Event.touchDown)
    }
    
    func done(){
        self.button.backgroundColor = UIColor.blue
    }
    
    func notDone(){
        self.button.backgroundColor = UIColor.white
        self.button.layer.borderWidth = 1
        self.button.layer.borderColor = UIColor.blue.cgColor
    }
    
    
    @objc fileprivate func doneButtonTriggered(_ sender: UIButton) {
        isAlert = !isAlert
        doneButtonAction?(isAlert)
    }
}
