//
//  TodoModel.swift
//  ToDos
//
//  Created by 陶思雨 on 2021/7/5.
//

import Foundation

struct ToDoModel : Encodable {
    var active: Bool = true
    var notes: String? = nil
    var isComplete: Bool = false
    
    init(active : Bool, notes : String, isComplete : Bool) {
        self.active = active
        self.notes = notes
        self.isComplete = isComplete
    }
    
    init?(dictionary : [String:Any]) {
        guard let active = dictionary["active"],
            let notes = dictionary["notes"],
            let isComplete = dictionary["isComplete"] else { return nil }
        self.init(active: active as! Bool, notes: notes as! String, isComplete: isComplete as! Bool)
    }

    var propertyListRepresentation : [String:Any] {
        return ["active" : active, "notes" : notes ?? "", "isComplete" : isComplete]
    }
}

extension ToDoModel {
    static var testData = [
        ToDoModel(active: false, notes: "这是一段测试代码", isComplete: false),
        ToDoModel(active: false, notes: "这是一段测试代码", isComplete: false),
        ToDoModel(active: false, notes: "这是一段测试代码", isComplete: false),
        ToDoModel(active: false, notes: "这是一段测试代码", isComplete: false),
        ToDoModel(active: false, notes: "这是一段测试代码", isComplete: false),
        ToDoModel(active: false, notes: "这是一段测试代码", isComplete: false)
    ]
}


