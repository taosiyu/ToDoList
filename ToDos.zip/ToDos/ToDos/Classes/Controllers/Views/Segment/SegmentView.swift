//
//  SegmentView.swift
//  ToDos
//
//  Created by 陶思雨 on 2021/7/5.
//

import UIKit

class SegmentView: UIView {
    
    open var segmentStyle: SegmentStyle
    
    open var titleBtnOnClick:((_ label: UILabel, _ index: Int)->Void)?
    
    fileprivate var labelsArray: [UILabel]  = []
    
    fileprivate var titles: [String]
    
    fileprivate var currentIndex = 0
    
    fileprivate var oldIndex = 0
    
    /// 是否显示遮罩
    fileprivate lazy var coverView: UIView = {
        let cover = UIView()
        cover.layer.cornerRadius = segmentStyle.coverCornerRadius
        cover.layer.shadowOffset = CGSize.init(width: 0.5, height: 1.5)
        cover.layer.masksToBounds = true
        return cover
    }()
    
    fileprivate lazy var backView: UIView = {
        let bView = UIView()
        bView.layer.cornerRadius = segmentStyle.coverCornerRadius
        bView.layer.masksToBounds = true
        return bView
    }()
    
    //MARK:init
    
    public init(frame: CGRect, segmentStyle: SegmentStyle, titles: [String]){
        self.segmentStyle = segmentStyle
        self.titles = titles
        super.init(frame: frame)
        self.isAccessibilityElement = true
        self.accessibilityIdentifier = "SegmentView"
        // back
        self.setupBackView()
        
        setupTitles()
        // UI Frame
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate func setupBackView() {
        self.addSubview(self.backView)
        self.backView.backgroundColor = segmentStyle.coverBackgroundColor
        self.backView.frame = CGRect.init(x: segmentStyle.titleLeftRightMargin, y: segmentStyle.titleTopBottomMargin, width: bounds.size.width - CGFloat(segmentStyle.titleLeftRightMargin)*2.0, height: bounds.size.height - segmentStyle.titleTopBottomMargin*2.0)
    }
    
    fileprivate func setupTitles() {
        for (index, title) in titles.enumerated(){
            let label = UILabel(frame: CGRect.zero)
            label.tag = index
            label.text = title
            label.isAccessibilityElement = true
            label.accessibilityIdentifier = title
            label.backgroundColor = UIColor.clear
            label.font = UIFont.boldSystemFont(ofSize: 16)
            label.textColor = UIColor.black
            label.textAlignment = .center
            label.isUserInteractionEnabled = true
            // 添加点击手势
            let tapGes = UITapGestureRecognizer(target: self, action: #selector(self.titleLabelOnClick(_:)))
            label.addGestureRecognizer(tapGes)
            // 缓存label
            labelsArray.append(label)
            // 添加label
            self.addSubview(label)
        }
    }
    
    // 设置Frame
    fileprivate func setupUI() {
        // set title position
        setUpLabelsPosition()
        // set cover
        setupCover()
    
    }
    
    /// 设置label的位置
    fileprivate func setUpLabelsPosition() {
        var titleX: CGFloat = self.backView.frame.origin.x
        let titleY: CGFloat = self.backView.frame.origin.y
        let titleW: CGFloat = self.backView.bounds.size.width/CGFloat(titles.count)
        let titleH = self.backView.bounds.size.height
        for(index, label) in labelsArray.enumerated(){
            titleX = titleW * CGFloat(index) + self.backView.frame.origin.x
            label.frame = CGRect(x: titleX, y: titleY, width: titleW, height: titleH)
        }
    }
    
    fileprivate func setupCover(){
        coverView.backgroundColor = segmentStyle.coverColor
        self.insertSubview(coverView, at: 1)
        
        let coverX = labelsArray[0].frame.origin.x + segmentStyle.coverPadding
        let coverW = labelsArray[0].frame.size.width - segmentStyle.coverPadding * 2.0
        let coverH: CGFloat = labelsArray[0].frame.size.height - segmentStyle.coverPadding * 2.0
        let coverY = (bounds.size.height - coverH) / 2
        
        coverView.frame = CGRect(x: coverX, y: coverY, width: coverW, height: coverH)
    }

    
    //MARK: Action
    
    @objc fileprivate func titleLabelOnClick(_ tapGes: UITapGestureRecognizer){
        guard let currentLabel = tapGes.view as? UILabel else { return }
        currentIndex = currentLabel.tag
        print(currentLabel.tag)
        adjustTitleClick(true)
    }
    
    fileprivate func adjustTitleClick(_ animated: Bool){
        guard currentIndex != oldIndex else {
            return
        }
        let currentLabel = labelsArray[currentIndex]
        // 动画效果
        UIView.animate(withDuration: 0.3) {
            [unowned self] in
            coverView.frame.origin.x = currentLabel.frame.origin.x  + segmentStyle.coverPadding
            coverView.frame.size.width = currentLabel.frame.size.width - segmentStyle.coverPadding * 2.0
        }
        oldIndex = currentIndex
        
        titleBtnOnClick?(currentLabel, currentIndex)
    }
}
