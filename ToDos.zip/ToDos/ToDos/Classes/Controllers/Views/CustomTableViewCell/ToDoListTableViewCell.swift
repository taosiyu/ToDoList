//
//  ToDoListTableViewCell.swift
//  ToDos
//
//  Created by 陶思雨 on 2021/7/5.
//

import UIKit
import SnapKit

class ToDoListTableViewCell: UITableViewCell {
    
    private var todoModel: ToDoModel
    
    open var textFieldFinishEdit:((_ index: Int,_ text: String)->Void)?
    
    open var btnClickDone:((_ index: Int, _ isAlert: Bool)->Void)?
    
    public var titleField:UITextField = {
        let textField = UITextField.init()
        textField.font = UIFont.boldSystemFont(ofSize: 16)
        textField.placeholder = "Untiled Todo"
        return textField
    }()
    
    public var acButton:ImageButton = {
        let btn = ImageButton.init()
        btn.activeButton();
        return btn
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        todoModel = ToDoModel.init(active: false, notes: "", isComplete: false)
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        self.contentView.addSubview(self.titleField)
        self.contentView.addSubview(self.acButton)
        self.cellinit();
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    private func cellinit(){
        
        let conV = self.contentView
        
        self.acButton.snp.makeConstraints { (make) in
            make.width.height.equalTo(20)
            make.left.equalTo(conV.snp.left).offset(12)
            make.centerY.equalTo(conV.snp.centerY)
        }
        
        self.titleField.snp.makeConstraints { (make) in
            make.top.equalTo(conV.snp.top).offset(12)
            make.left.equalTo(conV.snp.left).offset(40)
            make.bottom.equalTo(conV.snp.bottom).offset(-12)
        }
        
        self.titleField.delegate = self;
        
        self.acButton.doneButtonAction = {(isAlert) in
            if let col =  self.btnClickDone{
                col(self.tag,isAlert)
            }
        }
    }
    
    func setCellModel(model:ToDoModel){
        self.todoModel = model
    }
    
    override func layoutSubviews() {
        self.titleField.text = todoModel.notes
        self.todoModel.isComplete ? acButton.done() : acButton.notDone()
        self.acButton.isAlert = self.todoModel.isComplete
        self.titleField.isEnabled = true
        self.titleField.textColor = UIColor.black
        if self.todoModel.isComplete {
            self.titleField.isEnabled = false
            self.titleField.textColor = UIColor.gray
        }
        
    }

}


extension ToDoListTableViewCell : UITextFieldDelegate
{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let tempClo = textFieldFinishEdit {
            tempClo(self.tag,textField.text ?? "")
        }
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if let tempClo = textFieldFinishEdit {
            tempClo(self.tag,textField.text ?? "")
        }
    }
    
}
