//
//  SegmentStyle.swift
//  ToDos
//
//  Created by 陶思雨 on 2021/7/6.
//

import Foundation

import UIKit
/// Segment样式
public struct SegmentStyle{
    ///
    public var coverBackgroundColor = UIColor(red: 225.0/255.0, green: 225.0/255.0, blue: 239/255.0, alpha: 1.0)
    
    public var coverCornerRadius : CGFloat = 10.0
    
    public var coverColor = UIColor.white
    
    public var coverPadding : CGFloat = 2.0
    
    public var titleTopBottomMargin : CGFloat = 6.0
    
    public var titleLeftRightMargin : CGFloat = 8.0
    
    public var normalTitleColor = UIColor(red: 51.0/255.0, green: 53.0/255.0, blue: 75/255.0, alpha: 1.0)
    
    public var selectedTitleColor = UIColor(red: 255.0/255.0, green: 0.0/255.0, blue: 121/255.0, alpha: 1.0)
    public init() {
        
    }
}
