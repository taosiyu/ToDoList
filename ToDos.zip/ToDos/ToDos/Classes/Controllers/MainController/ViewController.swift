//
//  ViewController.swift
//  ToDos
//
//  Created by 陶思雨 on 2021/7/5.
//

import UIKit

class ViewController: UIViewController {
    
    enum kTableViewType {
        case All
        case Active
        case Completed
    }
    
    fileprivate let todoListCellIdentifier = "todoListCell"
    
    fileprivate var todoAllModelList : [ToDoModel] = []
    fileprivate var todoActiveModelList : [ToDoModel] = []
    fileprivate var todoCompletedList : [ToDoModel] = []
    fileprivate var todoShowList : [ToDoModel] = []
    
    fileprivate var tableViewType : kTableViewType = .All
    
    private lazy var mainTableView: UITableView = {
        return self.initTableView()
    }()
    
    private lazy var mainSegmentView: SegmentView = {
        return self.initSegmentView()
    }()
    
    private lazy var clearButton: UIBarButtonItem = {
        let clearBtn = UIBarButtonItem(title: "Clear Completed", style: UIBarButtonItem.Style.done, target: self, action: #selector(onClear))
        clearBtn.isEnabled = false
        return clearBtn
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.titleSetting(title: "ToDos");
        
        //init set TableView
        self.setTableView();
        
        //init
        self.setSegmentView()
        
        self.loadData()
        
        self.setNavitem()
        
    }
    
    //MARK:set views
    
    fileprivate func setTableView() {
        self.view.addSubview(self.mainTableView);
        self.mainTableView.frame = view.bounds;

    }
    
    fileprivate func setSegmentView() {
        self.mainTableView.tableHeaderView = self.mainSegmentView
        self.mainSegmentView.titleBtnOnClick = {[weak self] (label ,index) in
            self?.mainSegmentViewClick(index: index)
        }
        
    }
    
    //MARK:init

    fileprivate func titleSetting(title: String) {
        self.title = title
        self.navigationController?.navigationBar.prefersLargeTitles = true;
        navigationItem.largeTitleDisplayMode = .always
    }
    
    fileprivate func loadData(){
        self.todoAllModelList = loadList()
        self.todoShowList = self.todoAllModelList
        self.todoActiveModelList = todoAllModelList.filter { (item) -> Bool in
            return item.isComplete == false
        }
        self.todoCompletedList = todoAllModelList.filter { (item) -> Bool in
            return item.isComplete == true
        }
        self.refreshTableView()
    }
    
    fileprivate func saveData(){
        self.todoAllModelList = self.todoActiveModelList + self.todoCompletedList
        saveList(list: self.todoAllModelList)
    }
    
    //MARK: init Views
    
    fileprivate func initTableView() -> UITableView {
        let tableView = UITableView.init();
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.estimatedRowHeight = 90
        tableView.tableFooterView = UIView.init();
        tableView.register(ToDoListTableViewCell.self, forCellReuseIdentifier: todoListCellIdentifier)
        
        return tableView;
    }
    
    fileprivate func initSegmentView() -> SegmentView {
        let style = SegmentStyle()
        let segmentview = SegmentView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 60), segmentStyle:style, titles: ["All","Active","Completed"])
        return segmentview
    }
    
    //MARK:init navigationBar item
    
    //创建一个导航项
    fileprivate func setNavitem() {
        let navigationItem = self.navigationItem
        let editBtn = UIBarButtonItem(title: "Edit", style: UIBarButtonItem.Style.done, target: self, action: #selector(onEdit))
        let addBtn = UIBarButtonItem(title: "Add Todo", style: UIBarButtonItem.Style.done, target: self, action: #selector(onAddTado))
        clearButton.isEnabled = self.todoCompletedList.count > 0
        navigationItem.setRightBarButtonItems([addBtn,clearButton,editBtn], animated: false)
    }
    
    //MARK:action
    
    fileprivate func refreshTableView(){
        self.mainTableView.reloadData()
        clearButton.isEnabled = self.todoCompletedList.count > 0
    }
    
    @objc fileprivate func onEdit(){
        self.mainTableView.setEditing(!self.mainTableView.isEditing, animated: false)
        self.refreshTableView()
    }
    
    @objc fileprivate func onClear(){
        self.todoCompletedList.removeAll()
        self.changeTableViewType(type: tableViewType)
        self.saveData()
    }
    
    @objc fileprivate func onAddTado(){
        let todoModel = ToDoModel.init(active: false, notes: "", isComplete: false)
        self.todoActiveModelList.insert(todoModel, at: 0)
        self.changeTableViewType(type: tableViewType)
        self.saveData()
    }
    
    fileprivate func changeTableViewType(type : kTableViewType){
        self.todoShowList = self.getTableViewDataList(type: type)
        self.refreshTableView()
    }
    
    fileprivate func getTableViewDataList(type : kTableViewType) -> [ToDoModel]{
        switch type {
        case .Active:
            return self.todoActiveModelList
        case .Completed:
            return self.todoCompletedList
        default:
            return self.todoActiveModelList + self.todoCompletedList
        }
    }
    
    fileprivate func mainSegmentViewClick(index : Int){
        switch index {
        case 0:
            tableViewType = .All
            break
        case 1:
            tableViewType = .Active
            break
        case 2:
            tableViewType = .Completed
            break
        default:
            break
            
        }
        
        self.changeTableViewType(type: tableViewType)
    }

}


extension ViewController : UITableViewDelegate,UITableViewDataSource
{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todoShowList.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: self.todoListCellIdentifier, for: indexPath) as? ToDoListTableViewCell else {
            fatalError("Unable to dequeue ToDoListTableViewCell")
        }
        let todoModel = self.todoShowList[indexPath.row]
        cell.setCellModel(model: todoModel)
        cell.tag = indexPath.row
        cell.textFieldFinishEdit = {[unowned self](index,text) in
            if self.tableViewType == .Active {
                self.todoActiveModelList[indexPath.row].notes = text
            }else if self.tableViewType == .Completed {
                self.todoCompletedList[indexPath.row].notes = text
            }else{
                if indexPath.row < self.todoActiveModelList.count {
                    self.todoActiveModelList[indexPath.row].notes = text
                }else{
                    let trueIndex = indexPath.row - self.todoActiveModelList.count
                    self.todoCompletedList[trueIndex].notes = text
                }
            }
            
            self.changeCell(indexPath: indexPath)
            self.todoShowList = self.getTableViewDataList(type: tableViewType)
            self.mainTableView.reloadRows(at: [indexPath], with: .none)
        }
        cell.btnClickDone = {[unowned self](index,isAlert) in
            if self.tableViewType == .All {
                if indexPath.row < self.todoActiveModelList.count {
                    var todoModel = self.todoActiveModelList[indexPath.row]
                    todoModel.isComplete = isAlert
                    self.todoActiveModelList.remove(at: indexPath.row)
                    self.todoCompletedList.append(todoModel)
                }else{
                    let trueIndex = indexPath.row - self.todoActiveModelList.count
                    var todoModel = self.todoCompletedList[trueIndex]
                    todoModel.isComplete = isAlert
                    self.todoCompletedList.remove(at: trueIndex)
                    self.todoActiveModelList.append(todoModel)
                }
            }else{
                if isAlert == true {
                    var todoModel = self.todoActiveModelList[indexPath.row]
                    todoModel.isComplete = isAlert
                    self.todoActiveModelList.remove(at: indexPath.row)
                    self.todoCompletedList.append(todoModel)
                }else{
                    var todoModel = self.todoCompletedList[indexPath.row]
                    todoModel.isComplete = isAlert
                    self.todoCompletedList.remove(at: indexPath.row)
                    self.todoActiveModelList.append(todoModel)
                }
            }
            
            self.changeCell(indexPath: indexPath)
            self.todoShowList = self.getTableViewDataList(type: tableViewType)
            self.refreshTableView()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle ==  UITableViewCell.EditingStyle.delete{
            self.todoShowList.remove(at: indexPath.row)
            if self.tableViewType == .All {
                if indexPath.row < self.todoActiveModelList.count {
                    self.todoActiveModelList.remove(at: indexPath.row)
                }else{
                    let trueIndex = indexPath.row - self.todoActiveModelList.count
                    self.todoCompletedList.remove(at: trueIndex)
                }
            }else if self.tableViewType == .Active{
                self.todoActiveModelList.remove(at: indexPath.row)
            }else{
                self.todoCompletedList.remove(at: indexPath.row)
            }
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
            
            self.changeTableViewType(type: tableViewType)
            self.saveData()
        }
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return UITableViewCell.EditingStyle.delete
    }
    
    fileprivate func changeCell(indexPath: IndexPath){
        self.saveData()
    }
    
}

