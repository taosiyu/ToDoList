//
//  ToDosUITests.swift
//  ToDosUITests
//
//  Created by 陶思雨 on 2021/7/5.
//

import XCTest

class ToDosUITests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testAddTodo() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()
        let count = app.tables.cells.count
        // 定位元素
        let addButton = app.buttons["Add Todo"]
        addButton.tap()
        
        // 验证测试是否通过
        XCTAssertEqual(app.tables.cells.count, count+1)
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testClearCompleted() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()
        
        let count = app.tables.cells.count
        // 定位元素
        let addButton = app.buttons["Add Todo"]
        addButton.tap()
        
        let cell = app.tables.cells.firstMatch
        let textF = cell.textFields.firstMatch
        let textButton = cell.buttons.firstMatch
        XCTAssertTrue(textF.exists, "Text field doesn't exist")
        textF.tap()
        textF.typeText("ceshi")
        textButton.tap()
        
        XCTAssertEqual(app.tables.cells.count, count+1)
        
        let clearButton = app.buttons["Clear Completed"]
        clearButton.tap()
        
        XCTAssertEqual(app.tables.cells.count, count)
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testSwipeLeftDelete(){
        let app = XCUIApplication()
        app.launch()
        
        let count = app.tables.cells.count
        let tablesQuery = app.tables.cells
        tablesQuery.element(boundBy: 0).swipeLeft()
        tablesQuery.buttons["Delete"].tap()
        
        XCTAssertEqual(app.tables.cells.count, count-1)
    }
    
    func testSegment(){
        let app = XCUIApplication()
        app.launch()
                                                
//        let count = app.tables.cells.count
        let tableview = app.tables.firstMatch
        let segmentView = tableview.otherElements["SegmentView"]
        
        XCTAssertTrue(segmentView.exists, "doesn't exist")
            //嗯，取了半天没有取到对应的UILabel,这部分展示后面再补上测试吧。。第一次写自测用力 >_<
//        let activebtn = segmentView.staticTexts.element(matching: XCUIElement.ElementType.any, identifier: "Active")
//        let combtn = app.staticTexts.element(matching: XCUIElement.ElementType.any, identifier: "Active")
//        activebtn.tap()
//        XCTAssertEqual(app.tables.cells.count, count)
//        combtn.tap()
        XCTAssertEqual(app.tables.cells.count, 0)
    }

    func testLaunchPerformance() throws {
        if #available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 7.0, *) {
            // This measures how long it takes to launch your application.
            measure(metrics: [XCTApplicationLaunchMetric()]) {
                XCUIApplication().launch()
            }
        }
    }
}
